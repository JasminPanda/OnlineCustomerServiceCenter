package com.capgemini.model.service.dao;

import com.capgemini.model.entity.Department;

public interface DepartmentDao {

	void save(Department entity);

}
