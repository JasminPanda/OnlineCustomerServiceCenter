package com.capgemini.model.entity;

public class Admin {

}
