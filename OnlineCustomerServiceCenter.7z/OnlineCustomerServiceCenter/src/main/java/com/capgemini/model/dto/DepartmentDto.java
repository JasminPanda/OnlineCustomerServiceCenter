package com.capgemini.model.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class DepartmentDto {
	private int deptID;
	private String deptName;
	public Object getDepartmentName() {
		// TODO Auto-generated method stub
		return null;
	}

}
