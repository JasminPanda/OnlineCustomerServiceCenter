package com.capgemini.model.dto;

import lombok.Data;

@Data
public class AppError {
		private String code;
		private String message;
		public void setCode(String string) {
			// TODO Auto-generated method stub
			
		}
		public void setMessage(String message2) {
			// TODO Auto-generated method stub
			
		}
}
